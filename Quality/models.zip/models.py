from django.db import models
from django.contrib.auth.models import BaseUserManager, AbstractBaseUser





class UserManager(BaseUserManager):
    def create_user(self, email, username,role, password=None):
        """
        Creates and saves a User with the given email,  and password.
        """
        if not email:
            raise ValueError("Users must have an email address")

        user = self.model(
            email=self.normalize_email(email),
            username=username,
            role=role
        )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, username,role,password=None):
        """
        Creates and saves a superuser with the given email, date of
        birth and password.
        """
        user = self.create_user(
            email,
            role,
            username,
            password=password,
            
        )
        user.is_admin = True
        user.save(using=self._db)
        return user


class User(AbstractBaseUser):
    id = models.AutoField(primary_key=True)
    username=models.CharField(max_length=250)
    email = models.EmailField(verbose_name="email address",max_length=255,unique=True,) 
    ROLE_CHOICES = [
    ('manager', 'Manager'),
    ('quality_checker', 'Quality Checker'),
    ('teamlead', 'Team Lead'),
]



    role=models.CharField(max_length=250,choices=ROLE_CHOICES)
    is_active = models.BooleanField(default=True)
    is_admin = models.BooleanField(default=False)

    objects = UserManager()

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["username","role"]

    def __str__(self):
        return self.email

    def has_perm(self, perm, obj=None):
        "Does the user have a specific permission?"
        # Simplest possible answer: Yes, always
        return self.is_admin

    def has_module_perms(self, app_label):
        "Does the user have permissions to view the app `app_label`?"
        # Simplest possible answer: Yes, always
        return self.is_admin

    @property
    def is_staff(self):
        "Is the user a member of staff?"
        # Simplest possible answer: All admins are staff
        return self.is_admin
    
class Project(models.Model):
    PROJECT_CHOICES = [
    ('Project_Eagle', 'Project Eagle'),
    ('Project_Original', 'Project Original'),
    ('Project_Dspace', 'Project Dspace'),
]
    project_name=models.CharField(max_length=250, choices=PROJECT_CHOICES)
    project_Id=models.IntegerField()
    def __str__(self):
        return self.project_name


class Project_types(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='tasks')  
    TASK_TYPE=[
        ('2d bb creation','2D BB Creation'),
        ('3d bb creation', '3D BB Creation'),
        ('2d bb check and correct','2D BB Check and Correct'),
        ('3dbb/2d bb deletion','3DBB/2D BB Deletion'),
        ('2d polyline','2D Polyline'),
        ('3d/2d bb dynamic','3D/2D BB DYNAMIC'),
        ('3d/2d bb static','3D/2D BB STATIC')

    ] 

    task_type = models.CharField(max_length=250,choices=TASK_TYPE)


    

class Team(models.Model):
    id = models.AutoField(primary_key=True)
    Team_choice=[
        ('Team_Pioneers','UAI Team'),
        ('Team_Pixel','UAI Team'),
        ('Team_Alpha','Magna Team'),
        ('Team_Phoenix','Up2datz')
    ]
    team_name=models.CharField(max_length=250,choices=Team_choice)
    lead_name=models.CharField(max_length=50,default='other')
    


class Annotaor(models.Model):
    team_name=models.ForeignKey(Team,on_delete=models.CASCADE,related_name='Annotator' ,null=True, blank=True)
    annotator_name=models.CharField(max_length=250)
    # LEAD_NAME=[
    #     ('Vinay/Pooja','vinay/pooja'),
    #     ('Rajan','rajan'),
    #     ('Guru','guru'),
    #     ('Gokul','gokul')
    # ]

    



class Quality_check(models.Model):
    id = models.AutoField(primary_key=True)
    Date=models.DateField(auto_now=False, auto_now_add=False)
    project_name=models.ForeignKey(Project,on_delete=models.CASCADE,related_name='Quality_name', null=True, blank=True)
    task_type=models.ForeignKey(Project_types,on_delete=models.CASCADE,related_name='Quality_name', null=True, blank=True)
    qualitycheck_by=models.ForeignKey(User,on_delete=models.CASCADE,related_name='Quality_name', null=True, blank=True)
    annotator_name=models.ForeignKey(Annotaor,on_delete=models.CASCADE,related_name='Quality_name', null=True, blank=True)
    clip_name=models.CharField(max_length=250)
    total_annotation=models.IntegerField()
    objects_checked=models.IntegerField()
    attibutes_error=models.IntegerField()
    geometry_precision_error=models.IntegerField()
    tracking_error=models.IntegerField()
    class_label_error=models.IntegerField()
    missing_error=models.IntegerField()
    unwanted_bbox_error=models.IntegerField()
    comments=models.CharField(max_length=250)


class Qualitycheck_Output(models.Model):
    id = models.AutoField(primary_key=True)
    attibute_percentage=models.CharField(max_length=50)
    geometry_percentage=models.CharField(max_length=50)
    tracking_percentage=models.CharField(max_length=50)
    tracking_percentage=models.CharField(max_length=50)
    class_percentage=models.CharField(max_length=50)
    missing_percentage=models.CharField(max_length=50)
    bbox_percentage=models.CharField(max_length=50)
    annotatorquality_percentage=models.CharField(max_length=50)
    qc_id=models.ForeignKey(Quality_check,on_delete=models.CASCADE,related_name='Quality_name', null=True, blank=True)